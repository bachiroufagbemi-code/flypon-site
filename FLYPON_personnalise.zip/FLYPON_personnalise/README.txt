FLYPON — Version personnalisée
Fichiers :
- index.html : site responsive
- assets/flypon-logo.svg : logo FLYPON

Réseaux :
- Facebook : lien fourni.
- WhatsApp : lien wa.me configuré avec l'indicatif du Bénin (229). Le numéro fourni était 0193314646 : vérifie qu'il est exact et actif avant de partager le site.
- TikTok : lien générique provisoire. Remplace https://www.tiktok.com/ par le lien de ton profil lorsque tu l'auras.

Pour mettre à jour GitHub Pages :
1. Ouvre ton dépôt GitHub flypon-site.
2. Téléverse le nouveau index.html à la racine du dépôt (Add file > Upload files).
3. Téléverse également assets/flypon-logo.svg en conservant exactement le chemin assets/flypon-logo.svg. Le logo doit se trouver dans un dossier nommé assets.
4. Si GitHub indique qu'un fichier index.html existe déjà, tu peux remplacer son contenu via le crayon Edit, ou supprimer l'ancien puis téléverser le nouveau.
5. Valide avec Commit changes et attends quelques minutes avant de recharger le site.

Important : pour afficher une vraie photo personnelle, il faudra remplacer le logo temporaire dans le bloc photo et ajouter ta photo au dépôt. N'envoie que des photos que tu acceptes de rendre publiques.
